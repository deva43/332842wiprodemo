# Terraform: Interview Questions & Detailed Answers

## Table of Contents
1. [Terraform Basics](#terraform-basics)
2. [State Management](#state-management)
3. [Modules](#modules)
4. [Variables and Outputs](#variables-and-outputs)
5. [Functions and Expressions](#functions-and-expressions)
6. [Provisioners and null Resources](#provisioners-and-null-resources)
7. [Workspaces](#workspaces)
8. [Backends](#backends)
9. [Security](#security)
10. [Best Practices](#best-practices)
11. [Advanced Topics](#advanced-topics)
12. [Troubleshooting](#troubleshooting)

---

## Terraform Basics

### Q1: What is Terraform and what are its main benefits?

**Answer:**

Terraform is an open-source Infrastructure as Code (IaC) tool created by HashiCorp that allows you to define, provision, and manage cloud infrastructure using declarative configuration files.

**Key Characteristics:**

1. **Declarative Language**
   - You describe the desired state, not the steps to achieve it
   - Terraform figures out what needs to be created/modified/destroyed
   - More intuitive than imperative approaches

2. **Infrastructure as Code**
   - Infrastructure defined in version-controllable text files
   - Enables CI/CD pipelines for infrastructure
   - Reproducible deployments
   - Documentation as code

3. **Multi-Cloud Support**
   - AWS, Azure, GCP, Kubernetes, Heroku, and 1000+ providers
   - Same configuration language across clouds
   - Cloud-agnostic workflow

**Main Benefits:**

| Benefit | Description |
|---------|-------------|
| **Automation** | Automate resource provisioning and management |
| **Consistency** | Same configuration deployed identically every time |
| **Scalability** | Manage thousands of resources efficiently |
| **Version Control** | Track infrastructure changes like code |
| **Collaboration** | Team collaboration with state sharing |
| **Cost Estimation** | Plan costs before applying changes |
| **Modularity** | Reusable components and configurations |
| **Documentation** | Infrastructure documented in code |

**Example: Basic Terraform Configuration**

```hcl
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = "us-east-1"
}

# Define an EC2 instance
resource "aws_instance" "example" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"

  tags = {
    Name = "example-instance"
  }
}
```

**Terraform Workflow:**

```
┌─────────────────────────────────────────┐
│  1. WRITE                               │
│  Create .tf configuration files         │
└──────────────────┬──────────────────────┘
                   ↓
┌─────────────────────────────────────────┐
│  2. PLAN                                │
│  Review what will be created/changed    │
│  terraform plan                         │
└──────────────────┬──────────────────────┘
                   ↓
┌─────────────────────────────────────────┐
│  3. APPLY                               │
│  Execute the plan and create resources  │
│  terraform apply                        │
└──────────────────┬──────────────────────┘
                   ↓
┌─────────────────────────────────────────┐
│  State File Created (.tfstate)          │
│  Tracks actual infrastructure           │
└─────────────────────────────────────────┘
```

---

### Q2: What are providers and why are they important?

**Answer:**

Providers are plugins that Terraform uses to interact with cloud platforms, APIs, and services. They are the bridge between Terraform and the infrastructure platforms.

**Types of Providers:**

1. **Official Providers** (Maintained by HashiCorp)
   - AWS, Azure, Google Cloud, Kubernetes, etc.
   - High quality and actively maintained
   - Official support

2. **Partner Providers** (Maintained by technology partners)
   - Datadog, New Relic, Sumo Logic, etc.
   - Community partners collaborating with HashiCorp

3. **Community Providers** (Maintained by community)
   - Various third-party integrations
   - Community-supported

**Provider Configuration:**

```hcl
# Single provider
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"  # Version constraints
    }
  }
}

provider "aws" {
  region = "us-east-1"

  default_tags {
    tags = {
      Environment = "production"
      ManagedBy   = "Terraform"
    }
  }
}

# Multiple AWS providers (aliases)
provider "aws" {
  alias  = "us-west"
  region = "us-west-2"
}

# Using the aliased provider
resource "aws_instance" "us_west" {
  provider      = aws.us-west
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"
}
```

**Multi-Cloud Example:**

```hcl
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.0"
    }
    google = {
      source  = "hashicorp/google"
      version = "~> 4.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

provider "azurerm" {
  features {}
}

provider "google" {
  project = var.gcp_project
  region  = var.gcp_region
}

# AWS resource
resource "aws_instance" "example" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"
}

# Azure resource
resource "azurerm_resource_group" "example" {
  name     = "rg-example"
  location = "East US"
}

# GCP resource
resource "google_compute_instance" "example" {
  name         = "example-instance"
  machine_type = "e2-medium"
}
```

**Provider Argument Reference:**

```hcl
# Common provider arguments (example AWS)
provider "aws" {
  region              = "us-east-1"
  profile             = "production"     # AWS profile
  skip_credentials_validation = true
  skip_metadata_api_check     = true
  skip_region_validation      = true
  
  # Using environment variables
  # AWS_ACCESS_KEY_ID
  # AWS_SECRET_ACCESS_KEY
  # AWS_SESSION_TOKEN (for temporary credentials)
}
```

---

### Q3: What is the difference between terraform init, plan, apply, and destroy?

**Answer:**

These are the four main Terraform commands in the workflow:

**1. terraform init**

Initializes a Terraform working directory. Must be run before any other command.

```bash
terraform init

# Output:
# - Downloads and installs required providers
# - Creates .terraform directory
# - Initializes backend
# - Creates .terraform.lock.hcl (dependency lock file)
```

**What it does:**
- Downloads provider plugins
- Initializes the backend (state storage)
- Creates lock file for reproducible installations
- Validates provider configuration

```hcl
# To specify backend during init
terraform init \
  -backend-config="bucket=my-bucket" \
  -backend-config="key=terraform/state" \
  -backend-config="region=us-east-1"
```

**2. terraform plan**

Shows what Terraform will do without making changes.

```bash
terraform plan

# Output shows:
# + Resource will be created
# ~ Resource will be modified
# - Resource will be destroyed

# Save plan for later use
terraform plan -out=tfplan
```

**Plan Output Example:**
```
Terraform will perform the following actions:

  # aws_instance.example will be created
  + resource "aws_instance" "example" {
      + ami                    = "ami-0c55b159cbfafe1f0"
      + arn                    = (known after apply)
      + associate_public_ip    = (known after apply)
      + availability_zone      = (known after apply)
      + instance_type          = "t2.micro"
      + key_name               = (known after apply)
      + public_dns             = (known after apply)
      + public_ip              = (known after apply)
      + subnet_id              = (known after apply)
      + vpc_security_group_ids = (known after apply)
    }

Plan: 1 to add, 0 to change, 0 to destroy.
```

**3. terraform apply**

Executes the plan and applies changes to infrastructure.

```bash
# Apply with interactive approval
terraform apply

# Apply without approval prompt (use with caution!)
terraform apply -auto-approve

# Apply previously saved plan
terraform apply tfplan

# Apply with variable overrides
terraform apply -var="instance_type=t2.small"

# Apply specific resource
terraform apply -target=aws_instance.example
```

**What it does:**
- Creates/modifies/deletes resources as needed
- Updates state file to track actual infrastructure
- Shows what changed
- Prompts for confirmation (unless -auto-approve)

**4. terraform destroy**

Removes all managed infrastructure.

```bash
# Destroy with confirmation
terraform destroy

# Destroy without confirmation
terraform destroy -auto-approve

# Destroy specific resource
terraform destroy -target=aws_instance.example

# Destroy specific resource type in a module
terraform destroy -target='module.networking.aws_subnet.example'
```

**Complete Workflow Example:**

```bash
# 1. Initialize working directory
terraform init

# 2. Create/modify configuration files
cat > main.tf << 'EOF'
resource "aws_instance" "example" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"
}
EOF

# 3. Review what will happen
terraform plan

# 4. Apply the configuration
terraform apply

# 5. Later, destroy when done
terraform destroy
```

**Important Commands Related to This Workflow:**

```bash
# Check for syntax errors
terraform validate

# Format code for consistency
terraform fmt

# Show current state
terraform show

# List resources in state
terraform state list

# Import existing resource
terraform import aws_instance.example i-1234567890abcdef0
```

---

## State Management

### Q4: What is Terraform state and why is it critical?

**Answer:**

Terraform state is a file that stores the mapping between your configuration and actual infrastructure resources. It's the single source of truth.

**State File Structure:**

```json
{
  "version": 4,
  "terraform_version": "1.5.0",
  "serial": 42,
  "lineage": "abc123-def456",
  "outputs": {
    "instance_id": {
      "value": "i-1234567890abcdef0",
      "type": "string"
    }
  },
  "resources": [
    {
      "type": "aws_instance",
      "name": "example",
      "instances": [
        {
          "attributes": {
            "ami": "ami-0c55b159cbfafe1f0",
            "instance_type": "t2.micro",
            "id": "i-1234567890abcdef0",
            "public_ip": "54.123.45.67"
          }
        }
      ]
    }
  ]
}
```

**Why State is Critical:**

| Reason | Explanation |
|--------|-------------|
| **Tracking** | Maps configuration to real resources |
| **Performance** | Caches resource data to avoid repeated API calls |
| **Metadata** | Stores resource dependencies and relationships |
| **Collaboration** | Enables team coordination on shared infrastructure |
| **Safety** | Prevents accidental deletion or duplication |
| **Drift Detection** | Identifies manual changes to infrastructure |

**State Locations:**

1. **Local State** (Default)
```bash
# Stored in current directory
# File: terraform.tfstate
# Not recommended for team environments
```

2. **Remote State** (Recommended)
```hcl
# S3 backend (AWS)
terraform {
  backend "s3" {
    bucket         = "my-terraform-state"
    key            = "prod/terraform.tfstate"
    region         = "us-east-1"
    encrypt        = true
    dynamodb_table = "terraform-locks"
  }
}
```

**Sensitive Data in State:**

```hcl
# Sensitive values are stored in plain text in state file
resource "aws_db_instance" "example" {
  db_name  = "mydb"
  username = "admin"
  password = random_password.db.result  # Stored in state!
  
  # Sensitive marks it for UI hiding (not encryption)
  sensitive = true
}

output "database_password" {
  value       = aws_db_instance.example.password
  sensitive   = true  # Hides from terminal output
  description = "Database password (sensitive)"
}
```

**State Commands:**

```bash
# Display entire state
terraform state show

# Show specific resource
terraform state show aws_instance.example

# List all resources
terraform state list

# Remove resource from state (doesn't destroy it)
terraform state rm aws_instance.example

# Move resource to different location
terraform state mv aws_instance.old aws_instance.new

# Pull remote state locally
terraform state pull > backup.tfstate

# Push local state to remote
terraform state push backup.tfstate

# Lock state (requires DynamoDB table)
terraform state lock
terraform state unlock
```

**State File Security Best Practices:**

```hcl
# Enable encryption for remote state
terraform {
  backend "s3" {
    bucket            = "my-terraform-state"
    key               = "terraform.tfstate"
    region            = "us-east-1"
    encrypt           = true              # Enable encryption
    dynamodb_table    = "terraform-locks" # Enable locking
  }
}

# Restrict access to state file (S3 bucket policy)
resource "aws_s3_bucket_public_access_block" "terraform_state" {
  bucket = aws_s3_bucket.terraform_state.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_versioning" "terraform_state" {
  bucket = aws_s3_bucket.terraform_state.id

  versioning_configuration {
    status = "Enabled"  # Track state file history
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "terraform_state" {
  bucket = aws_s3_bucket.terraform_state.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}
```

---

### Q5: What is state locking and how does it work?

**Answer:**

State locking prevents concurrent modifications to infrastructure by multiple users/processes, preventing race conditions and state corruption.

**How State Locking Works:**

```
User 1: terraform apply           User 2: terraform apply
    ↓                                    ↓
    Acquires lock                        Waiting...
    ↓                                    ↓
    Modifies state                       Blocked by lock
    ↓                                    ↓
    Releases lock                        Acquires lock
    ↓                                    ↓
                                    Modifies state
                                    Releases lock
```

**Implementing State Locking with S3 + DynamoDB:**

```hcl
# Backend configuration with locking
terraform {
  backend "s3" {
    bucket            = "terraform-state-prod"
    key               = "prod/terraform.tfstate"
    region            = "us-east-1"
    encrypt           = true
    dynamodb_table    = "terraform-locks"
  }
}

# DynamoDB table for state locks
resource "aws_dynamodb_table" "terraform_locks" {
  name           = "terraform-locks"
  billing_mode   = "PAY_PER_REQUEST"
  hash_key       = "LockID"

  attribute {
    name = "LockID"
    type = "S"
  }

  tags = {
    Name = "Terraform State Lock Table"
  }
}

# S3 bucket for state
resource "aws_s3_bucket" "terraform_state" {
  bucket = "terraform-state-prod"

  tags = {
    Name = "Terraform State Bucket"
  }
}
```

**State Lock Info:**

```json
{
  "ID": "prod/terraform.tfstate",
  "Path": "prod/terraform.tfstate",
  "Operation": "OperationTypeApply",
  "Who": "user@hostname",
  "Version": "1.5.0",
  "Created": "2024-01-15T10:30:45Z",
  "Info": ""
}
```

**Handling Lock Issues:**

```bash
# List locks
aws dynamodb scan --table-name terraform-locks

# Force unlock (use with caution!)
terraform force-unlock <LOCK_ID>

# Check lock status before operations
terraform state list
```

**Best Practice: Preventing Concurrent Access**

```hcl
# Use local backend with file locking (not recommended for teams)
terraform {
  backend "local" {
    path = "terraform.tfstate"
  }
}

# Better: Use remote backend with automatic locking (S3 + DynamoDB)
terraform {
  backend "s3" {
    bucket            = "terraform-state"
    key               = "terraform.tfstate"
    region            = "us-east-1"
    dynamodb_table    = "terraform-locks"
  }
}
```

---

## Modules

### Q6: What are Terraform modules and why should you use them?

**Answer:**

Modules are containers for reusable Terraform configurations. They organize code, promote reusability, and enable infrastructure composition.

**Module Structure:**

```
my-module/
├── main.tf           # Primary resources
├── variables.tf      # Input variables
├── outputs.tf        # Output values
├── terraform.tf      # Version and provider requirements
├── README.md         # Documentation
└── examples/
    └── basic/
        ├── main.tf
        └── terraform.tfvars
```

**Creating a Module:**

```hcl
# modules/vpc/main.tf
resource "aws_vpc" "main" {
  cidr_block           = var.cidr_block
  enable_dns_hostnames = true

  tags = {
    Name = var.vpc_name
  }
}

resource "aws_subnet" "main" {
  vpc_id            = aws_vpc.main.id
  cidr_block        = var.subnet_cidr
  availability_zone = var.availability_zone

  tags = {
    Name = var.subnet_name
  }
}

resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id

  tags = {
    Name = var.igw_name
  }
}

# modules/vpc/variables.tf
variable "cidr_block" {
  type        = string
  description = "CIDR block for VPC"
}

variable "subnet_cidr" {
  type        = string
  description = "CIDR block for subnet"
}

variable "availability_zone" {
  type        = string
  description = "AZ for subnet"
}

variable "vpc_name" {
  type        = string
  description = "Name of VPC"
}

variable "subnet_name" {
  type        = string
  description = "Name of subnet"
}

variable "igw_name" {
  type        = string
  description = "Name of internet gateway"
}

# modules/vpc/outputs.tf
output "vpc_id" {
  value       = aws_vpc.main.id
  description = "ID of VPC"
}

output "vpc_cidr" {
  value       = aws_vpc.main.cidr_block
  description = "CIDR block of VPC"
}

output "subnet_id" {
  value       = aws_subnet.main.id
  description = "ID of subnet"
}

output "igw_id" {
  value       = aws_internet_gateway.main.id
  description = "ID of internet gateway"
}
```

**Using a Module:**

```hcl
# main.tf
module "vpc" {
  source = "./modules/vpc"

  cidr_block       = "10.0.0.0/16"
  subnet_cidr      = "10.0.1.0/24"
  availability_zone = "us-east-1a"
  vpc_name         = "prod-vpc"
  subnet_name      = "prod-subnet"
  igw_name         = "prod-igw"
}

# Access module outputs
resource "aws_instance" "example" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"
  subnet_id     = module.vpc.subnet_id

  tags = {
    Name = "example-instance"
  }
}
```

**Module Sources:**

```hcl
# Local module
module "vpc" {
  source = "./modules/vpc"
}

# GitHub repository
module "vpc" {
  source = "git::https://github.com/myorg/terraform-modules.git//vpc?ref=v1.0.0"
}

# Terraform Registry (public)
module "vpc" {
  source = "terraform-aws-modules/vpc/aws"
  version = "~> 5.0"
}

# Private registry (Terraform Cloud/Enterprise)
module "vpc" {
  source = "app.terraform.io/myorg/vpc/aws"
  version = "~> 1.0"
}

# S3 bucket
module "vpc" {
  source = "s3::https://s3.amazonaws.com/mybucket/modules/vpc.zip"
}

# HTTP
module "vpc" {
  source = "https://example.com/terraform-modules/vpc.zip"
}
```

**Benefits of Modules:**

| Benefit | Description |
|---------|-------------|
| **Reusability** | Use same configuration multiple times |
| **Organization** | Logical grouping of resources |
| **Maintainability** | Updates in one place affect all uses |
| **Testing** | Easy to test in isolation |
| **Documentation** | Self-contained and documentable |
| **Composition** | Build complex infrastructure from simple blocks |
| **Versioning** | Track changes and versions |

---

### Q7: How do you structure a large Terraform project?

**Answer:**

Organizing Terraform projects for scalability, maintainability, and collaboration.

**Directory Structure (Recommended):**

```
terraform/
├── environments/
│   ├── dev/
│   │   ├── main.tf
│   │   ├── terraform.tfvars
│   │   ├── outputs.tf
│   │   └── backend.tf
│   ├── staging/
│   │   ├── main.tf
│   │   ├── terraform.tfvars
│   │   ├── outputs.tf
│   │   └── backend.tf
│   └── prod/
│       ├── main.tf
│       ├── terraform.tfvars
│       ├── outputs.tf
│       └── backend.tf
├── modules/
│   ├── networking/
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   ├── outputs.tf
│   │   └── README.md
│   ├── compute/
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   ├── outputs.tf
│   │   └── README.md
│   ├── database/
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   ├── outputs.tf
│   │   └── README.md
│   └── security/
│       ├── main.tf
│       ├── variables.tf
│       ├── outputs.tf
│       └── README.md
├── variables.tf
├── terraform.tf
├── terraform.tfvars
├── outputs.tf
├── .gitignore
├── .terraform.lock.hcl
└── README.md
```

**Root Configuration (terraform.tf):**

```hcl
terraform {
  required_version = ">= 1.5"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }

  backend "s3" {
    # Backend config handled per environment
  }
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Environment = var.environment
      Project     = var.project_name
      ManagedBy   = "Terraform"
    }
  }
}
```

**Root Variables (variables.tf):**

```hcl
variable "aws_region" {
  type        = string
  description = "AWS region"
  default     = "us-east-1"
}

variable "environment" {
  type        = string
  description = "Environment name"
  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "Environment must be dev, staging, or prod."
  }
}

variable "project_name" {
  type        = string
  description = "Project name for tagging"
}
```

**Environment Configuration (environments/prod/main.tf):**

```hcl
terraform {
  backend "s3" {
    bucket            = "my-terraform-state"
    key               = "prod/terraform.tfstate"
    region            = "us-east-1"
    encrypt           = true
    dynamodb_table    = "terraform-locks"
  }
}

locals {
  environment = "prod"
  cidr_block  = "10.1.0.0/16"
}

module "networking" {
  source = "../../modules/networking"

  vpc_cidr = local.cidr_block
  environment = local.environment
  project_name = var.project_name
}

module "compute" {
  source = "../../modules/compute"

  vpc_id = module.networking.vpc_id
  environment = local.environment
  project_name = var.project_name

  depends_on = [module.networking]
}

module "database" {
  source = "../../modules/database"

  vpc_id = module.networking.vpc_id
  environment = local.environment
  project_name = var.project_name

  depends_on = [module.networking]
}
```

**Environment Variables (environments/prod/terraform.tfvars):**

```hcl
aws_region   = "us-east-1"
environment  = "prod"
project_name = "my-app"
```

**Best Practices for Project Structure:**

1. **Separate by Environment**: Dev, staging, prod directories
2. **Use Modules**: Group related resources
3. **Consistent Naming**: Follow naming conventions
4. **Documentation**: README files in each module
5. **Terraform Registry**: Use published modules when possible
6. **Backend per Environment**: Separate state files
7. **Version Control**: Track .tf and .tfvars files, ignore .tfstate

---

## Variables and Outputs

### Q8: Explain variable types, validation, and best practices.

**Answer:**

Variables allow parametrization of Terraform configurations for reusability and flexibility.

**Variable Types:**

```hcl
# Simple types
variable "instance_type" {
  type        = string
  description = "EC2 instance type"
  default     = "t2.micro"
}

variable "instance_count" {
  type        = number
  description = "Number of instances"
  default     = 1
}

variable "enable_monitoring" {
  type        = bool
  description = "Enable CloudWatch monitoring"
  default     = true
}

# Collection types
variable "instance_tags" {
  type = map(string)
  description = "Tags for instance"
  default = {
    Name = "example"
    Env  = "dev"
  }
}

variable "availability_zones" {
  type        = list(string)
  description = "List of AZs"
  default     = ["us-east-1a", "us-east-1b"]
}

# Object type
variable "db_config" {
  type = object({
    engine               = string
    version              = string
    instance_class       = string
    allocated_storage    = number
    publicly_accessible  = bool
  })
  description = "Database configuration"
  default = {
    engine               = "postgres"
    version              = "14"
    instance_class       = "db.t3.micro"
    allocated_storage    = 20
    publicly_accessible  = false
  }
}

# Tuple type (fixed-length collection)
variable "cors_settings" {
  type = tuple([string, number, bool])
  description = "CORS settings"
  default     = ["https://example.com", 3600, true]
}

# Set type (unordered, unique values)
variable "allowed_protocols" {
  type        = set(string)
  description = "Allowed protocols"
  default     = ["HTTP", "HTTPS"]
}
```

**Variable Validation:**

```hcl
variable "instance_type" {
  type        = string
  description = "EC2 instance type"

  validation {
    condition     = contains(["t2.micro", "t2.small", "t2.medium"], var.instance_type)
    error_message = "Instance type must be t2.micro, t2.small, or t2.medium."
  }
}

variable "environment" {
  type        = string
  description = "Environment"

  validation {
    condition     = can(regex("^(dev|staging|prod)$", var.environment))
    error_message = "Environment must be dev, staging, or prod."
  }
}

variable "port" {
  type        = number
  description = "Port number"

  validation {
    condition     = var.port >= 1 && var.port <= 65535
    error_message = "Port must be between 1 and 65535."
  }
}

variable "db_config" {
  type = object({
    engine = string
    version = string
  })

  validation {
    condition = (
      var.db_config.engine == "postgres" && (
        var.db_config.version == "13" || 
        var.db_config.version == "14"
      )
    ) || (
      var.db_config.engine == "mysql" && (
        var.db_config.version == "8.0"
      )
    )
    error_message = "Valid engine/version combinations: postgres 13|14, mysql 8.0."
  }
}
```

**Variable Assignment Methods:**

```bash
# 1. terraform.tfvars (automatic)
terraform apply

# 2. Command line
terraform apply -var="instance_type=t2.small"

# 3. Environment variable
export TF_VAR_instance_type="t2.small"
terraform apply

# 4. Variables file
terraform apply -var-file="prod.tfvars"

# 5. Interactive prompt
# If not provided, Terraform will prompt

# 6. .tfvars files (auto-loaded)
# terraform.tfvars
# terraform.prod.tfvars (if using -auto-tfvars flag)
```

**Variable Best Practices:**

```hcl
# ✓ Good: Descriptive names and descriptions
variable "enable_deletion_protection" {
  type        = bool
  description = "Enable deletion protection for RDS instance"
  default     = true
}

# ✗ Bad: Unclear naming
variable "flag" {
  type    = bool
  default = true
}

# ✓ Good: Use validation
variable "log_retention_days" {
  type        = number
  description = "CloudWatch logs retention"

  validation {
    condition     = contains([1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1827, 3653], var.log_retention_days)
    error_message = "Log retention must be a valid CloudWatch Logs value."
  }
}

# ✓ Good: Use sensitive for passwords
variable "db_password" {
  type        = string
  description = "Database password"
  sensitive   = true
}

# ✓ Good: Use locals for computed values
locals {
  common_tags = {
    Environment = var.environment
    Project     = var.project_name
    ManagedBy   = "Terraform"
  }
}
```

**Outputs:**

```hcl
# Simple output
output "instance_id" {
  value       = aws_instance.example.id
  description = "EC2 instance ID"
}

# Sensitive output
output "db_password" {
  value       = aws_db_instance.example.password
  description = "Database password"
  sensitive   = true
}

# Complex output
output "vpc_details" {
  value = {
    vpc_id    = aws_vpc.main.id
    cidr_block = aws_vpc.main.cidr_block
    subnets = {
      public = aws_subnet.public.*.id
      private = aws_subnet.private.*.id
    }
  }
  description = "VPC configuration details"
}

# Output referencing module
output "load_balancer_dns" {
  value       = module.load_balancer.dns_name
  description = "Load balancer DNS name"
}
```

---

## Functions and Expressions

### Q9: Explain important Terraform functions and when to use them.

**Answer:**

Terraform includes built-in functions for string manipulation, collection operations, type conversion, and more.

**String Functions:**

```hcl
# String manipulation
resource "aws_instance" "example" {
  tags = {
    # upper() - Convert to uppercase
    Env = upper("dev")  # "DEV"
    
    # lower() - Convert to lowercase
    Team = lower("DevOps")  # "devops"
    
    # concat() - Concatenate strings
    Name = concat("prod-", var.instance_name)  # "prod-webserver"
    
    # join() - Join list into string
    Domains = join(",", var.domain_names)  # "a.com,b.com"
    
    # split() - Split string into list
    # split(",", "a,b,c")  # ["a", "b", "c"]
    
    # substr() - Substring
    # substr("hello", 1, 3)  # "ell"
    
    # length() - String length
    # length("terraform")  # 9
    
    # replace() - Replace substring
    # replace("hello world", "world", "terraform")  # "hello terraform"
    
    # trim() - Remove whitespace
    # trim("  hello  ")  # "hello"
  }
}
```

**Collection Functions:**

```hcl
# Working with lists
locals {
  # length() - Get list length
  az_count = length(var.availability_zones)  # 3
  
  # element() - Get element at index
  first_az = element(var.availability_zones, 0)
  
  # concat() - Concatenate lists
  all_tags = concat(var.default_tags, var.additional_tags)
  
  # distinct() - Remove duplicates
  unique_values = distinct(var.tags_list)
  
  # sort() - Sort list
  sorted_azs = sort(var.availability_zones)
  
  # reverse() - Reverse list
  reversed = reverse(local.sorted_azs)
  
  # contains() - Check if value in list
  has_https = contains(var.protocols, "HTTPS")
  
  # index() - Find index of value
  https_index = index(var.protocols, "HTTPS")
  
  # flatten() - Flatten nested lists
  # flatten([[1,2], [3,4]])  # [1,2,3,4]
  
  # merge() - Merge maps
  combined_tags = merge(var.default_tags, var.custom_tags)
  
  # keys() - Get map keys
  tag_keys = keys(var.tags)
  
  # values() - Get map values
  tag_values = values(var.tags)
  
  # lookup() - Get map value with default
  env = lookup(var.config, "environment", "dev")
}
```

**Type Conversion Functions:**

```hcl
# Type conversions
locals {
  # tostring() - Convert to string
  port_string = tostring(var.port)  # "8080"
  
  # tonumber() - Convert to number
  count_num = tonumber("5")  # 5
  
  # tobool() - Convert to boolean
  enabled = tobool("true")  # true
  
  # tolist() - Convert to list
  items = tolist(var.item_set)
  
  # tomap() - Convert to map
  map_from_list = tomap(var.key_value_list)
  
  # toset() - Convert to set
  unique_items = toset(var.items)
}
```

**Conditional Functions:**

```hcl
# Using if-then-else
resource "aws_instance" "example" {
  instance_type = var.environment == "prod" ? "t3.large" : "t3.micro"
  
  # Nested conditionals
  availability_zone = (
    var.environment == "prod" ? var.prod_az :
    var.environment == "staging" ? var.staging_az :
    var.dev_az
  )
  
  # Using try() for error handling
  subnet_id = try(var.custom_subnet_id, module.vpc.subnet_id)
  
  # Using can() to check validity
  use_specific_az = can(data.aws_availability_zone.selected.id) ? 1 : 0
}
```

**Utility Functions:**

```hcl
# Useful functions
locals {
  # format() - String formatting
  name = format("%s-%s-%s", var.environment, var.region, var.project)
  
  # base64encode() / base64decode() - Encoding
  encoded = base64encode(var.config_data)
  
  # file() - Read file contents
  script = file("${path.module}/scripts/init.sh")
  
  # templatefile() - Template with variables
  config = templatefile("${path.module}/config.tpl", {
    environment = var.environment
    port        = var.port
  })
  
  # jsonencode() / jsondecode() - JSON operations
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [...]
  })
  
  # range() - Generate range of numbers
  numbers = range(1, 5)  # [1, 2, 3, 4]
}
```

**Using Functions in Resource Creation:**

```hcl
# Real-world example
resource "aws_security_group" "web" {
  name        = format("sg-%s-%s", var.environment, var.app_name)
  description = "Security group for ${upper(var.app_name)} - ${var.environment}"

  dynamic "ingress" {
    for_each = var.allowed_ports
    content {
      from_port   = ingress.value
      to_port     = ingress.value
      protocol    = "tcp"
      cidr_blocks = split(",", var.allowed_cidrs)
    }
  }

  tags = merge(
    var.common_tags,
    {
      Name = format("sg-%s-%s", var.environment, var.app_name)
    }
  )
}
```

---

## Provisioners and null Resources

### Q10: What are provisioners and when should they be used?

**Answer:**

Provisioners are a way to run scripts or commands on resources during creation or destruction. They should be a last resort.

**Types of Provisioners:**

```hcl
resource "aws_instance" "example" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"

  # local-exec: Runs on machine running Terraform
  provisioner "local-exec" {
    command = "echo 'Instance created' >> instance.log"
  }

  # remote-exec: Runs on the remote resource
  provisioner "remote-exec" {
    inline = [
      "sudo apt-get update",
      "sudo apt-get install -y nginx",
      "sudo systemctl start nginx"
    ]

    connection {
      type        = "ssh"
      user        = "ec2-user"
      private_key = file("~/.ssh/id_rsa")
      host        = self.public_ip
    }
  }

  # file: Copy files to remote resource
  provisioner "file" {
    source      = "local/path/config.conf"
    destination = "/tmp/config.conf"

    connection {
      type        = "ssh"
      user        = "ec2-user"
      private_key = file("~/.ssh/id_rsa")
      host        = self.public_ip
    }
  }
}
```

**Provisioner On Failure:**

```hcl
resource "aws_instance" "example" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"

  provisioner "remote-exec" {
    inline = [
      "sudo apt-get update",
      "sudo apt-get install -y application"
    ]

    # Continue even if provisioner fails
    on_failure = continue

    connection {
      type        = "ssh"
      user        = "ec2-user"
      private_key = file("~/.ssh/id_rsa")
      host        = self.public_ip
    }
  }
}
```

**Provisioner When Destroying:**

```hcl
resource "aws_instance" "example" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"

  # Run during destroy
  provisioner "remote-exec" {
    when = destroy

    inline = [
      "sudo systemctl stop nginx",
      "sudo apt-get remove -y nginx"
    ]

    connection {
      type        = "ssh"
      user        = "ec2-user"
      private_key = file("~/.ssh/id_rsa")
      host        = self.public_ip
    }
  }
}
```

**Better Alternatives to Provisioners:**

**1. User Data (Recommended)**
```hcl
resource "aws_instance" "web" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"

  # User data runs at instance startup
  user_data = base64encode(<<-EOF
    #!/bin/bash
    sudo apt-get update
    sudo apt-get install -y nginx
    sudo systemctl start nginx
  EOF
  )

  tags = {
    Name = "web-server"
  }
}
```

**2. Cloud-Init**
```hcl
resource "aws_instance" "example" {
  ami                    = "ami-0c55b159cbfafe1f0"
  instance_type          = "t2.micro"
  iam_instance_profile   = aws_iam_instance_profile.example.name

  user_data = base64encode(templatefile("${path.module}/cloud-init.yaml", {
    environment = var.environment
    region      = var.aws_region
  }))
}
```

**3. Configuration Management Tools**
```hcl
# Using Ansible
resource "aws_instance" "example" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"

  tags = {
    Name = "example"
  }
}

resource "null_resource" "ansible_provisioner" {
  provisioner "local-exec" {
    command = "ansible-playbook -i '${aws_instance.example.public_ip},' playbook.yml"
  }

  depends_on = [aws_instance.example]
}
```

**4. Docker Image (Best)**
```hcl
resource "docker_container" "app" {
  image = docker_image.app.id
  name  = "my-app"

  ports {
    internal = 8080
    external = 8080
  }

  # Configuration baked into image
}
```

**Why Avoid Provisioners:**

| Issue | Impact |
|-------|--------|
| **Complexity** | Hard to debug and understand |
| **Idempotency** | Scripts may not be idempotent |
| **State Issues** | Can leave resources in inconsistent state |
| **Error Handling** | Difficult error handling and recovery |
| **Maintenance** | Hard to maintain over time |
| **Testing** | Hard to test provisioner logic |

**When Provisioners Are Acceptable:**

- Quick debugging and testing
- Running non-idempotent scripts (with care)
- Legacy system integration
- Last resort when no other option exists

---

## Workspaces

### Q11: What are Terraform workspaces and when to use them?

**Answer:**

Workspaces are separate named states within a single backend, allowing multiple instances of the same configuration.

**Workspace Basics:**

```bash
# List workspaces
terraform workspace list

# Create new workspace
terraform workspace new dev
terraform workspace new staging
terraform workspace new prod

# Select workspace
terraform workspace select prod

# Delete workspace
terraform workspace delete dev

# Show current workspace
terraform workspace show
```

**Using Workspaces in Configuration:**

```hcl
# Reference current workspace
locals {
  environment = terraform.workspace
  
  # Different configuration per workspace
  instance_type = {
    default = "t2.micro"
    dev     = "t2.micro"
    staging = "t2.small"
    prod    = "t2.large"
  }
}

resource "aws_instance" "example" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = local.instance_type[local.environment]

  tags = {
    Environment = local.environment
  }
}
```

**Workspace-Specific Variables:**

```hcl
# terraform.dev.tfvars
instance_count = 1
instance_type  = "t2.micro"
db_size        = "db.t2.micro"

# terraform.staging.tfvars
instance_count = 2
instance_type  = "t2.small"
db_size        = "db.t2.small"

# terraform.prod.tfvars
instance_count = 3
instance_type  = "t2.medium"
db_size        = "db.t3.medium"
```

**Workflow with Workspaces:**

```bash
# Develop in dev workspace
terraform workspace select dev
terraform plan -var-file="terraform.dev.tfvars"
terraform apply -var-file="terraform.dev.tfvars"

# Test in staging
terraform workspace select staging
terraform plan -var-file="terraform.staging.tfvars"
terraform apply -var-file="terraform.staging.tfvars"

# Deploy to prod
terraform workspace select prod
terraform plan -var-file="terraform.prod.tfvars"
terraform apply -var-file="terraform.prod.tfvars"
```

**Workspaces vs Directory Structure:**

| Aspect | Workspaces | Directory Structure |
|--------|-----------|-------------------|
| **State Storage** | Same backend, different states | Different backends |
| **Isolation** | Weak (can access other workspaces) | Strong |
| **Shared Configuration** | Reduced duplication | More repetition |
| **Complexity** | Simpler | More complex |
| **Collaboration** | Higher risk of accidents | More controlled |

**Recommendation:** Use directory structure for environments, workspaces for temporary branches.

---

## Backends

### Q12: Explain different backends and how to migrate between them.

**Answer:**

Backends determine where Terraform state is stored and how operations are performed.

**Backend Types:**

```hcl
# 1. Local Backend (Default)
terraform {
  backend "local" {
    path = "terraform.tfstate"
  }
}

# 2. S3 Backend (AWS)
terraform {
  backend "s3" {
    bucket            = "my-terraform-state"
    key               = "prod/terraform.tfstate"
    region            = "us-east-1"
    encrypt           = true
    dynamodb_table    = "terraform-locks"
    skip_region_validation = false
  }
}

# 3. Azure Backend
terraform {
  backend "azurerm" {
    resource_group_name  = "rg-terraform"
    storage_account_name = "storageaccount"
    container_name       = "tfstate"
    key                  = "terraform.tfstate"
  }
}

# 4. Google Cloud Storage Backend
terraform {
  backend "gcs" {
    bucket  = "tf-state-bucket"
    prefix  = "terraform/state"
  }
}

# 5. Terraform Cloud/Enterprise Backend
terraform {
  cloud {
    organization = "my-organization"

    workspaces {
      name = "my-workspace"
    }
  }
}

# 6. Consul Backend
terraform {
  backend "consul" {
    address      = "consul.example.com"
    path         = "terraform/"
    gzip         = true
    lock         = true
  }
}

# 7. etcd Backend
terraform {
  backend "etcd" {
    endpoints = ["http://etcd.example.com:2379"]
    path      = "/terraform"
  }
}

# 8. PostgreSQL Backend
terraform {
  backend "pg" {
    conn_str = "postgres://user:password@localhost/terraform"
  }
}
```

**Migrating Between Backends:**

```bash
# Step 1: Current state in local backend
# State file: terraform.tfstate

# Step 2: Configure new S3 backend
cat > backend.tf << 'EOF'
terraform {
  backend "s3" {
    bucket            = "my-terraform-state"
    key               = "prod/terraform.tfstate"
    region            = "us-east-1"
    encrypt           = true
    dynamodb_table    = "terraform-locks"
  }
}
EOF

# Step 3: Reinitialize Terraform (will prompt about migration)
terraform init

# When prompted:
# "Do you want to copy existing state to the new backend?"
# Answer: yes

# Step 4: Verify state migrated
terraform state list

# Step 5: Remove local state file (after verification)
rm terraform.tfstate*

# Step 6: Commit changes
git add backend.tf .terraform.lock.hcl
git commit -m "Migrate state to S3 backend"
```

**Automated Backend Migration Script:**

```bash
#!/bin/bash

OLD_BACKEND="local"
NEW_BACKEND="s3"

echo "Backing up current state..."
cp terraform.tfstate terraform.tfstate.backup

echo "Configuring new backend..."
cat > backend.tf << 'EOF'
terraform {
  backend "s3" {
    bucket            = "my-terraform-state"
    key               = "prod/terraform.tfstate"
    region            = "us-east-1"
    encrypt           = true
    dynamodb_table    = "terraform-locks"
  }
}
EOF

echo "Reinitializing Terraform..."
terraform init -migrate-state

echo "Verifying migration..."
terraform state list

echo "Migration complete! Old state backed up to terraform.tfstate.backup"
```

**S3 Backend Setup (Best Practice):**

```hcl
# Create S3 bucket for state
resource "aws_s3_bucket" "terraform_state" {
  bucket = "my-terraform-state-${data.aws_caller_identity.current.account_id}"

  tags = {
    Name = "Terraform State"
  }
}

# Enable versioning
resource "aws_s3_bucket_versioning" "terraform_state" {
  bucket = aws_s3_bucket.terraform_state.id

  versioning_configuration {
    status = "Enabled"
  }
}

# Enable encryption
resource "aws_s3_bucket_server_side_encryption_configuration" "terraform_state" {
  bucket = aws_s3_bucket.terraform_state.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

# Block public access
resource "aws_s3_bucket_public_access_block" "terraform_state" {
  bucket = aws_s3_bucket.terraform_state.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# Create DynamoDB table for locking
resource "aws_dynamodb_table" "terraform_locks" {
  name           = "terraform-locks"
  billing_mode   = "PAY_PER_REQUEST"
  hash_key       = "LockID"

  attribute {
    name = "LockID"
    type = "S"
  }

  tags = {
    Name = "Terraform State Lock"
  }
}

# Backend configuration
terraform {
  backend "s3" {
    bucket            = "my-terraform-state-123456"
    key               = "prod/terraform.tfstate"
    region            = "us-east-1"
    encrypt           = true
    dynamodb_table    = "terraform-locks"
  }
}
```

---

## Security

### Q13: How do you secure Terraform configurations and state?

**Answer:**

Security is critical for Terraform to protect infrastructure and sensitive data.

**Securing State Files:**

```hcl
# 1. Encrypt state at rest (S3)
terraform {
  backend "s3" {
    bucket            = "terraform-state"
    key               = "terraform.tfstate"
    region            = "us-east-1"
    encrypt           = true  # Enable encryption
    dynamodb_table    = "terraform-locks"
  }
}

# 2. Enable state locking
resource "aws_dynamodb_table" "terraform_locks" {
  name           = "terraform-locks"
  billing_mode   = "PAY_PER_REQUEST"
  hash_key       = "LockID"

  attribute {
    name = "LockID"
    type = "S"
  }
}

# 3. Restrict access to state
resource "aws_s3_bucket_policy" "terraform_state" {
  bucket = aws_s3_bucket.terraform_state.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          IAM = [
            "arn:aws:iam::ACCOUNT:role/terraform-role"
          ]
        }
        Action   = "s3:*"
        Resource = [
          aws_s3_bucket.terraform_state.arn,
          "${aws_s3_bucket.terraform_state.arn}/*"
        ]
      }
    ]
  })
}
```

**Securing Sensitive Variables:**

```hcl
# Mark sensitive variables
variable "db_password" {
  type        = string
  description = "Database password"
  sensitive   = true
}

variable "api_key" {
  type        = string
  description = "API key"
  sensitive   = true
}

# Sensitive outputs
output "database_password" {
  value       = aws_db_instance.example.password
  sensitive   = true
}

# Never in tfvars (use env vars or secrets manager)
# ✗ WRONG:
# db_password = "my-secret-password"

# ✓ RIGHT:
# export TF_VAR_db_password="my-secret-password"
# terraform apply

# ✓ BEST: Use AWS Secrets Manager
data "aws_secretsmanager_secret_version" "db_password" {
  secret_id = "rds/prod/password"
}

resource "aws_db_instance" "example" {
  master_username = "admin"
  master_userpassword = jsondecode(data.aws_secretsmanager_secret_version.db_password.secret_string)["password"]
}
```

**IAM for Terraform:**

```hcl
# Create IAM role for Terraform
resource "aws_iam_role" "terraform" {
  name = "terraform-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          AWS = "arn:aws:iam::ACCOUNT:root"
        }
        Action = "sts:AssumeRole"
      }
    ]
  })
}

# Attach policy with minimal permissions
resource "aws_iam_role_policy" "terraform" {
  name   = "terraform-policy"
  role   = aws_iam_role.terraform.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "ec2:*",
          "rds:*",
          "s3:*"
        ]
        Resource = "*"
      },
      {
        Effect = "Allow"
        Action = [
          "dynamodb:PutItem",
          "dynamodb:GetItem",
          "dynamodb:DeleteItem"
        ]
        Resource = "arn:aws:dynamodb:*:*:table/terraform-locks"
      }
    ]
  })
}
```

**Version Control Security:**

```bash
# .gitignore - Never commit sensitive files
.terraform/
terraform.tfvars
terraform.prod.tfvars
!terraform.example.tfvars
*.tfstate
*.tfstate.*
.DS_Store
crash.log
override.tf
override.tf.json
*_override.tf
*_override.tf.json
.env
.vscode/
```

**Using Git Secrets:**

```bash
# Install git-secrets
brew install git-secrets

# Initialize in repo
git secrets --install
git secrets --install -f  # Override existing hooks

# Add patterns to block
git secrets --add 'password'
git secrets --add 'api.key'
git secrets --add 'AWS_SECRET_ACCESS_KEY'

# Scan for secrets
git secrets --scan

# In CI/CD pipeline
git secrets --scan-history
```

**Terraform Cloud Security:**

```hcl
# Use Terraform Cloud for better security
terraform {
  cloud {
    organization = "my-organization"

    workspaces {
      name = "production"
    }
  }
}

# Terraform Cloud features:
# - Variable encryption
# - State encryption
# - Role-based access control
# - Audit logging
# - Team management
```

---

## Best Practices

### Q14: What are Terraform best practices?

**Answer:**

**1. Code Organization:**

```hcl
# Use consistent file structure
# main.tf - Main resources
# variables.tf - Input variables
# outputs.tf - Output values
# terraform.tf - Provider and version constraints
# locals.tf - Local values
```

**2. Naming Conventions:**

```hcl
# Use descriptive, consistent names
# Format: {component}-{purpose}-{environment}

resource "aws_instance" "web_server_prod" {
  tags = {
    Name = "web-server-prod"
  }
}

resource "aws_rds_cluster" "database_prod" {
  # ...
}

resource "aws_security_group" "web_servers_prod" {
  # ...
}
```

**3. Variable Validation:**

```hcl
variable "environment" {
  type        = string
  description = "Environment name"

  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "Environment must be dev, staging, or prod."
  }
}
```

**4. Use Modules:**

```hcl
# ✓ Good: Modular, reusable
module "vpc" {
  source = "./modules/vpc"
  cidr_block = var.vpc_cidr
}

module "database" {
  source = "./modules/database"
  vpc_id = module.vpc.vpc_id
}

# ✗ Bad: Copy-paste duplication
resource "aws_vpc" "prod" { ... }
resource "aws_vpc" "staging" { ... }
resource "aws_vpc" "dev" { ... }
```

**5. Remote State:**

```hcl
# ✓ Good: Shared, locked state
terraform {
  backend "s3" {
    bucket            = "terraform-state"
    dynamodb_table    = "terraform-locks"
    encrypt           = true
  }
}

# ✗ Bad: Local state (hard to collaborate)
# terraform.tfstate checked into git
```

**6. Sensitive Data Handling:**

```hcl
# ✓ Good: Use Secrets Manager or environment variables
data "aws_secretsmanager_secret_version" "db_password" {
  secret_id = "rds/password"
}

# ✗ Bad: Plaintext in tfvars
# db_password = "my-password"
```

**7. Testing:**

```bash
# Use terraform validate
terraform validate

# Use terraform plan and review
terraform plan -out=tfplan

# Use terraform fmt to enforce style
terraform fmt -recursive

# Use tflint for linting
tflint

# Use terratest for testing
go test -v ./test
```

**8. Documentation:**

```hcl
# Always include descriptions
variable "instance_count" {
  type        = number
  description = "Number of EC2 instances to create. Recommended: 1-3"
  default     = 1

  validation {
    condition     = var.instance_count >= 1 && var.instance_count <= 3
    error_message = "Instance count must be between 1 and 3."
  }
}

output "instance_ids" {
  value       = aws_instance.web[*].id
  description = "List of EC2 instance IDs"
}
```

**9. DRY Principle (Don't Repeat Yourself):**

```hcl
# ✓ Good: Using locals for repetition
locals {
  common_tags = {
    Environment = var.environment
    Project     = var.project_name
    ManagedBy   = "Terraform"
  }

  naming_prefix = "${var.project_name}-${var.environment}"
}

resource "aws_instance" "web" {
  tags = merge(
    local.common_tags,
    {
      Name = "${local.naming_prefix}-web-server"
    }
  )
}

# ✗ Bad: Repeating values
resource "aws_instance" "web" {
  tags = {
    Environment = var.environment
    Project     = var.project_name
    ManagedBy   = "Terraform"
    Name        = "${var.project_name}-${var.environment}-web-server"
  }
}
```

**10. Error Handling:**

```hcl
# Use try() and can() for graceful handling
resource "aws_instance" "example" {
  # Use custom VPC if provided, otherwise create default
  subnet_id = try(var.custom_subnet_id, aws_subnet.default[0].id)

  # Check if value is valid
  security_groups = can(var.security_group_ids) ? var.security_group_ids : [aws_security_group.default.id]
}
```

---

## Advanced Topics

### Q15: Explain advanced Terraform concepts.

**Answer:**

**1. Dynamic Blocks:**

```hcl
# Generate multiple blocks dynamically
resource "aws_security_group" "example" {
  name = "example"

  dynamic "ingress" {
    for_each = var.ingress_rules
    content {
      from_port       = ingress.value.from_port
      to_port         = ingress.value.to_port
      protocol        = ingress.value.protocol
      cidr_blocks     = ingress.value.cidr_blocks
      security_groups = ingress.value.security_groups
    }
  }

  tags = {
    Name = "example-sg"
  }
}

# Usage
variable "ingress_rules" {
  type = list(object({
    from_port       = number
    to_port         = number
    protocol        = string
    cidr_blocks     = list(string)
    security_groups = list(string)
  }))

  default = [
    {
      from_port       = 80
      to_port         = 80
      protocol        = "tcp"
      cidr_blocks     = ["0.0.0.0/0"]
      security_groups = []
    },
    {
      from_port       = 443
      to_port         = 443
      protocol        = "tcp"
      cidr_blocks     = ["0.0.0.0/0"]
      security_groups = []
    }
  ]
}
```

**2. Splat Expressions:**

```hcl
# Extract values from multiple resources
resource "aws_instance" "web" {
  count         = var.instance_count
  ami           = var.ami
  instance_type = var.instance_type
}

output "all_instance_ids" {
  # Splat expression extracts all IDs
  value = aws_instance.web[*].id
  # Output: ["i-001", "i-002", "i-003"]
}

output "all_private_ips" {
  value = aws_instance.web[*].private_ip
}

# Complex splat
output "instance_details" {
  value = aws_instance.web[*].{
    id   = id
    ip   = private_ip
    type = instance_type
  }
}
```

**3. Conditional Expressions:**

```hcl
locals {
  # Ternary operator
  environment_suffix = var.environment == "prod" ? "-prod" : "-dev"

  # Nested conditions
  instance_type = (
    var.workload == "compute" ? "c5.2xlarge" :
    var.workload == "memory" ? "r5.2xlarge" :
    var.workload == "general" ? "m5.2xlarge" :
    "t3.micro"
  )
}
```

**4. For Expressions:**

```hcl
# Transform lists/maps
variable "users" {
  type = list(object({
    name  = string
    email = string
  }))

  default = [
    { name = "Alice", email = "alice@example.com" },
    { name = "Bob", email = "bob@example.com" }
  ]
}

locals {
  # Create map of users by name
  users_by_name = {
    for user in var.users : user.name => user.email
  }
  # Output: { "Alice" = "alice@example.com", "Bob" = "bob@example.com" }

  # Filter users
  admin_emails = [
    for user in var.users : user.email if startswith(user.name, "A")
  ]
  # Output: ["alice@example.com"]

  # Create uppercase names
  user_names_upper = [
    for user in var.users : upper(user.name)
  ]
}
```

**5. Count Meta-Argument:**

```hcl
# Create multiple resources
resource "aws_instance" "web" {
  count         = var.instance_count
  ami           = var.ami
  instance_type = var.instance_type

  tags = {
    Name = "web-server-${count.index + 1}"
  }
}

# Access individual instances
output "first_instance_id" {
  value = aws_instance.web[0].id
}

# Access all instances
output "all_instance_ids" {
  value = aws_instance.web[*].id
}
```

**6. For_each Meta-Argument:**

```hcl
# Create resources for each item in a map
variable "environments" {
  type = map(object({
    instance_type = string
    instance_count = number
  }))

  default = {
    dev = {
      instance_type  = "t2.micro"
      instance_count = 1
    }
    prod = {
      instance_type  = "t3.large"
      instance_count = 3
    }
  }
}

resource "aws_instance" "web" {
  for_each      = var.environments
  ami           = var.ami
  instance_type = each.value.instance_type
  count         = each.value.instance_count

  tags = {
    Name = "web-${each.key}"
  }
}

# Access specific instance
output "dev_instances" {
  value = aws_instance.web["dev"][*].id
}
```

**7. Depends_on:**

```hcl
# Explicit dependencies
resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id

  tags = {
    Name = "main-igw"
  }
}

resource "aws_route" "internet_access" {
  route_table_id            = aws_route_table.main.id
  destination_cidr_block    = "0.0.0.0/0"
  gateway_id                = aws_internet_gateway.main.id

  # Explicit dependency even though it's implicit
  depends_on = [aws_internet_gateway.main]
}
```

**8. Locals for Computed Values:**

```hcl
locals {
  # Computed values using functions
  timestamp         = formatdate("YYYY-MM-DD", timestamp())
  environment_lower = lower(var.environment)
  
  # Complex logic
  subnet_count = var.enable_high_availability ? 3 : 1
  
  # Derived values
  resource_name = "${var.project}-${local.environment_lower}-${local.timestamp}"
}
```

---

## Troubleshooting

### Q16: Common Terraform issues and solutions.

**Answer:**

**Issue 1: State Lock**

```bash
# Error: Error acquiring the lock
# Cause: Another terraform process holds the lock

# Solution: Wait for lock to be released
# Or force unlock
terraform force-unlock <LOCK_ID>

# Check lock status
aws dynamodb scan --table-name terraform-locks
```

**Issue 2: State Drift**

```bash
# Error: Infrastructure has been modified outside Terraform

# Solution: Refresh state
terraform refresh

# Or plan and see what changed
terraform plan -refresh-only

# Import manually created resources
terraform import aws_instance.example i-1234567890abcdef0
```

**Issue 3: Attribute Not Found**

```bash
# Error: Error: Unsupported argument
# Cause: Using wrong attribute name or older provider version

# Solution:
# 1. Check provider documentation
# 2. Update provider version
# 3. Use correct attribute name

terraform init -upgrade
```

**Issue 4: Invalid Credentials**

```bash
# Error: Error: error reading S3 Bucket

# Solution:
# 1. Check AWS credentials
export AWS_ACCESS_KEY_ID="YOUR_KEY"
export AWS_SECRET_ACCESS_KEY="YOUR_SECRET"

# 2. Verify IAM permissions
# 3. Check region configuration
export AWS_DEFAULT_REGION="us-east-1"
```

**Issue 5: Resource Already Exists**

```bash
# Error: Error creating EC2 instance: InvalidParameterValue
# Cause: Resource already created outside Terraform

# Solution: Import resource
terraform import aws_instance.example i-1234567890abcdef0

# Or remove from state (only if destroying)
terraform state rm aws_instance.example
```

**Issue 6: Syntax Errors**

```bash
# Error: Error while loading schemas
# Cause: Syntax error in configuration

# Solution:
# 1. Validate configuration
terraform validate

# 2. Format code
terraform fmt -recursive

# 3. Check for typos and missing quotes
```

**Issue 7: Provider Version Conflicts**

```bash
# Error: required_version constraint not met

# Solution:
# 1. Check version
terraform version

# 2. Install correct version
terraform init -upgrade

# 3. Update requirements in terraform.tf
terraform {
  required_version = ">= 1.5"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}
```

**Debugging Commands:**

```bash
# Enable verbose logging
export TF_LOG=DEBUG
export TF_LOG_PATH=terraform.log
terraform plan

# Show detailed plan
terraform plan -out=tfplan
terraform show tfplan

# Validate configuration
terraform validate

# Format check
terraform fmt -check

# Show graph (requires GraphViz)
terraform graph

# Graph as visual
terraform graph | dot -Tsvg > graph.svg
```

**Common Debugging Patterns:**

```bash
# When terraform gets stuck
# 1. Check logs
tail -f terraform.log

# 2. Verify network connectivity
ping terraform.io

# 3. Check backend accessibility
aws s3 ls s3://my-terraform-state/

# 4. Review state file
terraform state show

# 5. Test plan dry-run
terraform plan -no-color > plan.txt
cat plan.txt

# 6. Reinitialize if all else fails
rm -rf .terraform
terraform init
```

**Prevention Best Practices:**

```bash
# 1. Always plan before apply
terraform plan -out=tfplan
terraform apply tfplan

# 2. Review changes carefully
terraform show tfplan

# 3. Use version control
git diff

# 4. Backup state before major changes
terraform state pull > backup.tfstate

# 5. Test in non-prod first
terraform workspace select dev
terraform apply

# 6. Use CI/CD for consistent workflow
# GitHub Actions / GitLab CI / Jenkins
```

---

## Quick Reference Commands

```bash
# Core commands
terraform init          # Initialize working directory
terraform validate      # Check configuration validity
terraform plan          # Preview changes
terraform apply         # Apply changes
terraform destroy       # Destroy resources
terraform fmt           # Format code
terraform state list    # List resources in state
terraform import        # Import existing resources
terraform workspace     # Manage workspaces

# Utility commands
terraform version       # Show version
terraform console       # Interactive console
terraform graph         # Show resource graph
terraform output        # Show outputs
terraform show          # Show state/plan
terraform refresh       # Refresh state
terraform taint         # Mark resource for recreation
terraform untaint       # Unmark resource
terraform lock          # Lock state
terraform unlock        # Unlock state

# Variables and configuration
terraform apply -var="key=value"                # Pass variable
terraform apply -var-file="vars.tfvars"        # Use vars file
terraform apply -auto-approve                  # Skip approval
terraform apply -target=resource.name           # Target specific resource
terraform apply -replace=resource.name          # Force replacement
```

---

## Conclusion

This comprehensive guide covers essential Terraform knowledge for interviews. Focus on understanding state management, modules, security, and best practices. Practice with real scenarios and stay updated with the latest Terraform features and AWS provider changes.

**Key Takeaways:**
- Terraform is powerful for infrastructure automation
- State management is critical and must be secured
- Modules enable code reuse and organization
- Always use remote state with locking for teams
- Implement strong security practices
- Follow naming conventions and documentation standards
- Test thoroughly before applying to production
- Monitor and maintain infrastructure continuously
