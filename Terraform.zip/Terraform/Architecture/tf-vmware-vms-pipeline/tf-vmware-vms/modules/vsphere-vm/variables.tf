variable "name" {
  description = "VM hostname (short name). Must follow the bank naming standard."
  type        = string

  validation {
    condition     = can(regex("^[a-z0-9]{3}(lnx|win)[a-z0-9]{2,10}[0-9]{2}$", var.name))
    error_message = "Name must match <site><os><app><nn>, e.g. dc1lnxapp0101."
  }
}

variable "os_type" {
  description = "Operating system family: linux or windows."
  type        = string

  validation {
    condition     = contains(["linux", "windows"], var.os_type)
    error_message = "os_type must be linux or windows."
  }
}

variable "template_name" {
  description = "Name of the approved, hardened vSphere template to clone."
  type        = string
}

variable "datacenter" {
  description = "vSphere datacenter name."
  type        = string
}

variable "cluster" {
  description = "vSphere compute cluster name."
  type        = string
}

variable "datastore" {
  description = "vSphere datastore or datastore cluster member to place the VM on."
  type        = string
}

variable "network" {
  description = "vSphere port group name."
  type        = string
}

variable "folder" {
  description = "vSphere VM folder path (relative to the datacenter)."
  type        = string
}

variable "num_cpus" {
  description = "Number of vCPUs."
  type        = number
  default     = 2

  validation {
    condition     = var.num_cpus >= 1 && var.num_cpus <= 16
    error_message = "num_cpus must be between 1 and 16 (larger sizes need an exception)."
  }
}

variable "memory_mb" {
  description = "Memory in MB."
  type        = number
  default     = 4096

  validation {
    condition     = var.memory_mb >= 1024 && var.memory_mb <= 65536
    error_message = "memory_mb must be between 1024 and 65536."
  }
}

variable "disk_size_gb" {
  description = "Size of the OS disk in GB. Must be >= template disk size."
  type        = number
  default     = 60
}

variable "ipv4_address" {
  description = "Static IPv4 address allocated from IPAM."
  type        = string
}

variable "ipv4_netmask" {
  description = "Prefix length, e.g. 24."
  type        = number
}

variable "ipv4_gateway" {
  description = "Default gateway."
  type        = string
}

variable "dns_servers" {
  description = "DNS server list."
  type        = list(string)
}

variable "domain" {
  description = "DNS domain / AD domain FQDN."
  type        = string
}

variable "time_zone_linux" {
  description = "Linux time zone (tz database)."
  type        = string
  default     = "Europe/London"
}

variable "time_zone_windows" {
  description = "Windows time zone index (85 = GMT Standard Time)."
  type        = number
  default     = 85
}

variable "windows_admin_password" {
  description = "Local Administrator password for Windows customisation (from CyberArk). Ignored for Linux."
  type        = string
  default     = null
  sensitive   = true
}

variable "windows_domain_join_user" {
  description = "Account used to join the AD domain (from CyberArk). Ignored for Linux."
  type        = string
  default     = null
}

variable "windows_domain_join_password" {
  description = "Password of the domain join account (from CyberArk). Ignored for Linux."
  type        = string
  default     = null
  sensitive   = true
}

variable "windows_ou" {
  description = "Target AD OU distinguished name for Windows computer objects."
  type        = string
  default     = null
}

variable "tags" {
  description = "Mandatory bank metadata, written to vSphere custom attributes and annotation."
  type = object({
    owner               = string
    cost_centre         = string
    environment         = string
    application         = string
    data_classification = string
    change_ref          = string
  })
}

variable "custom_attribute_ids" {
  description = "Map of tag key => vSphere custom attribute ID (created by the platform team)."
  type        = map(string)
}
