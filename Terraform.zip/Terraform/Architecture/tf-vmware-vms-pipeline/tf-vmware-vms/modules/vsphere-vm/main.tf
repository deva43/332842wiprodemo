data "vsphere_datacenter" "this" {
  name = var.datacenter
}

data "vsphere_compute_cluster" "this" {
  name          = var.cluster
  datacenter_id = data.vsphere_datacenter.this.id
}

data "vsphere_datastore" "this" {
  name          = var.datastore
  datacenter_id = data.vsphere_datacenter.this.id
}

data "vsphere_network" "this" {
  name          = var.network
  datacenter_id = data.vsphere_datacenter.this.id
}

data "vsphere_virtual_machine" "template" {
  name          = var.template_name
  datacenter_id = data.vsphere_datacenter.this.id
}

locals {
  is_windows = var.os_type == "windows"

  annotation = join("\n", [
    "Managed by Terraform (HCP Terraform). Do not change manually.",
    "Owner: ${var.tags.owner}",
    "Application: ${var.tags.application}",
    "Environment: ${var.tags.environment}",
    "Change: ${var.tags.change_ref}",
  ])

  custom_attributes = {
    for k, v in var.tags : var.custom_attribute_ids[k] => v
    if contains(keys(var.custom_attribute_ids), k)
  }
}

resource "vsphere_virtual_machine" "this" {
  name             = var.name
  folder           = var.folder
  resource_pool_id = data.vsphere_compute_cluster.this.resource_pool_id
  datastore_id     = data.vsphere_datastore.this.id

  num_cpus  = var.num_cpus
  memory    = var.memory_mb
  guest_id  = data.vsphere_virtual_machine.template.guest_id
  firmware  = data.vsphere_virtual_machine.template.firmware
  scsi_type = data.vsphere_virtual_machine.template.scsi_type

  annotation        = local.annotation
  custom_attributes = local.custom_attributes

  # Security baseline
  efi_secure_boot_enabled = data.vsphere_virtual_machine.template.firmware == "efi"
  enable_disk_uuid        = true
  sync_time_with_host     = false

  wait_for_guest_net_timeout = 10

  network_interface {
    network_id   = data.vsphere_network.this.id
    adapter_type = data.vsphere_virtual_machine.template.network_interface_types[0]
  }

  disk {
    label            = "disk0"
    size             = max(var.disk_size_gb, data.vsphere_virtual_machine.template.disks[0].size)
    thin_provisioned = data.vsphere_virtual_machine.template.disks[0].thin_provisioned
  }

  clone {
    template_uuid = data.vsphere_virtual_machine.template.id

    customize {
      timeout = 30

      dynamic "linux_options" {
        for_each = local.is_windows ? [] : [1]
        content {
          host_name = var.name
          domain    = var.domain
          time_zone = var.time_zone_linux
        }
      }

      dynamic "windows_options" {
        for_each = local.is_windows ? [1] : []
        content {
          computer_name         = var.name
          admin_password        = var.windows_admin_password
          join_domain           = var.domain
          domain_admin_user     = var.windows_domain_join_user
          domain_admin_password = var.windows_domain_join_password
          domain_ou             = var.windows_ou
          time_zone             = var.time_zone_windows
          auto_logon            = false
        }
      }

      network_interface {
        ipv4_address = var.ipv4_address
        ipv4_netmask = var.ipv4_netmask
      }

      ipv4_gateway    = var.ipv4_gateway
      dns_server_list = var.dns_servers
      dns_suffix_list = [var.domain]
    }
  }

  lifecycle {
    # Template updates must not force rebuilds of running VMs.
    ignore_changes = [clone[0].template_uuid, clone[0].customize]
  }
}
