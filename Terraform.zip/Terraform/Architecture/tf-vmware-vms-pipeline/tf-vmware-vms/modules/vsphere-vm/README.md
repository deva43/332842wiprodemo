# vsphere-vm module

Clones a hardened, approved vSphere template into a Linux or Windows VM with static
IP configuration, bank metadata (custom attributes + annotation) and guest customisation.

In production this module is published to the HCP Terraform private registry from a
semantic version tag and consumed as `app.terraform.io/<org>/vsphere-vm/vsphere`.
It is kept in this repository so the pipeline can be copied and run end to end.

Inputs and outputs: see variables.tf and outputs.tf.
