output "name" {
  description = "VM name."
  value       = vsphere_virtual_machine.this.name
}

output "fqdn" {
  description = "VM fully qualified domain name."
  value       = "${vsphere_virtual_machine.this.name}.${var.domain}"
}

output "ipv4_address" {
  description = "Primary IPv4 address."
  value       = vsphere_virtual_machine.this.default_ip_address
}

output "os_type" {
  description = "linux or windows (used to select the Ansible job template)."
  value       = var.os_type
}

output "moid" {
  description = "vSphere managed object ID."
  value       = vsphere_virtual_machine.this.moid
}
