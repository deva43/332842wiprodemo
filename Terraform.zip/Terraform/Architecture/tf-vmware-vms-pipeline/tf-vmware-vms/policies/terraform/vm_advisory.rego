# Advisory (non-blocking) VMware VM guidance.
package terraform.policies.vm_advisory

import rego.v1

plan := object.get(input, "plan", input)

warn contains msg if {
	some rc in plan.resource_changes
	rc.type == "vsphere_virtual_machine"
	"create" in rc.change.actions
	rc.change.after.num_cpus > 8
	msg := sprintf("%s: more than 8 vCPUs requested; confirm sizing with capacity team", [rc.address])
}

warn contains msg if {
	vms := object.get(plan, ["variables", "vms", "value"], {})
	some name, vm in vms
	vm.memory_mb > 32768
	msg := sprintf("%s: more than 32 GB RAM requested; confirm sizing", [name])
}
