# Mandatory VMware VM standards.
# Works with both HCP Terraform OPA input (input.plan.resource_changes) and a raw
# Terraform JSON plan used by conftest (input.resource_changes).
package terraform.policies.vm_standards

import rego.v1

plan := object.get(input, "plan", input)

vm_changes contains rc if {
	some rc in plan.resource_changes
	rc.type == "vsphere_virtual_machine"
	some action in rc.change.actions
	action in {"create", "update"}
}

approved_datastores := {"DC1-NP-DS01", "DC1-NP-DS02", "DC1-P-DS01", "DC1-P-DS02"}

approved_folders := {"Terraform/dev", "Terraform/test", "Terraform/prod"}

max_cpus := 16

max_memory_mb := 65536

# 1. Annotation must state the change reference (traceability).
deny contains msg if {
	some rc in vm_changes
	not contains(object.get(rc.change.after, "annotation", ""), "Change: CHG")
	msg := sprintf("%s: annotation must include an ITSM change reference (Change: CHG...)", [rc.address])
}

# 2. Mandatory custom attributes (6 bank metadata fields).
deny contains msg if {
	some rc in vm_changes
	attrs := object.get(rc.change.after, "custom_attributes", {})
	count(attrs) < 6
	msg := sprintf("%s: all 6 mandatory custom attributes must be set (found %d)", [rc.address, count(attrs)])
}

# 3. Size limits.
deny contains msg if {
	some rc in vm_changes
	rc.change.after.num_cpus > max_cpus
	msg := sprintf("%s: num_cpus %d exceeds limit %d", [rc.address, rc.change.after.num_cpus, max_cpus])
}

deny contains msg if {
	some rc in vm_changes
	rc.change.after.memory > max_memory_mb
	msg := sprintf("%s: memory %d MB exceeds limit %d MB", [rc.address, rc.change.after.memory, max_memory_mb])
}

# 4. Approved folders only.
deny contains msg if {
	some rc in vm_changes
	not rc.change.after.folder in approved_folders
	msg := sprintf("%s: folder %q is not approved", [rc.address, rc.change.after.folder])
}

# 5. Disk UUID must be enabled (required by backup and monitoring tooling).
deny contains msg if {
	some rc in vm_changes
	rc.change.after.enable_disk_uuid != true
	msg := sprintf("%s: enable_disk_uuid must be true", [rc.address])
}

# 6. No destroy or replace of VMs in prod without the explicit break-glass variable.
deny contains msg if {
	some rc in plan.resource_changes
	rc.type == "vsphere_virtual_machine"
	"delete" in rc.change.actions
	object.get(plan, ["variables", "environment", "value"], "") == "prod"
	msg := sprintf("%s: destroy/replace of a production VM is blocked by policy", [rc.address])
}

# 7. Only approved providers.
approved_providers := {
	"registry.terraform.io/vmware/vsphere",
	"registry.terraform.io/hashicorp/vsphere",
	"registry.terraform.io/cyberark/conjur",
}

deny contains msg if {
	some rc in plan.resource_changes
	not rc.provider_name in approved_providers
	msg := sprintf("%s: provider %s is not approved", [rc.address, rc.provider_name])
}

# 8. Approved datastores only. The plan records datastore IDs rather than names, so the
# names are checked from the root module "vms" input variable.
deny contains msg if {
	vms := object.get(plan, ["variables", "vms", "value"], {})
	some name, vm in vms
	not vm.datastore in approved_datastores
	msg := sprintf("%s: datastore %q is not approved", [name, vm.datastore])
}
