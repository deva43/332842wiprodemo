package terraform.policies.vm_standards_test

import rego.v1

import data.terraform.policies.vm_standards

good_vm := {
	"address": "module.vm[\"dc1lnxapp0101\"].vsphere_virtual_machine.this",
	"type": "vsphere_virtual_machine",
	"provider_name": "registry.terraform.io/vmware/vsphere",
	"change": {
		"actions": ["create"],
		"after": {
			"annotation": "Managed by Terraform\nChange: CHG0012345",
			"custom_attributes": {"601": "a", "602": "b", "603": "c", "604": "d", "605": "e", "606": "f"},
			"num_cpus": 2,
			"memory": 4096,
			"folder": "Terraform/dev",
			"enable_disk_uuid": true,
		},
	},
}

good_vars := {
	"environment": {"value": "dev"},
	"vms": {"value": {"dc1lnxapp0101": {"datastore": "DC1-NP-DS01", "memory_mb": 4096}}},
}

test_compliant_vm_passes if {
	count(vm_standards.deny) == 0 with input as {"plan": {"resource_changes": [good_vm], "variables": good_vars}}
}

test_raw_plan_input_supported if {
	count(vm_standards.deny) == 0 with input as {"resource_changes": [good_vm], "variables": good_vars}
}

test_oversized_vm_denied if {
	bad := json.patch(good_vm, [{"op": "replace", "path": "/change/after/num_cpus", "value": 32}])
	count(vm_standards.deny) == 1 with input as {"plan": {"resource_changes": [bad], "variables": good_vars}}
}

test_missing_change_ref_denied if {
	bad := json.patch(good_vm, [{"op": "replace", "path": "/change/after/annotation", "value": "no ref"}])
	count(vm_standards.deny) == 1 with input as {"plan": {"resource_changes": [bad], "variables": good_vars}}
}

test_unapproved_folder_denied if {
	bad := json.patch(good_vm, [{"op": "replace", "path": "/change/after/folder", "value": "Discovered virtual machine"}])
	count(vm_standards.deny) == 1 with input as {"plan": {"resource_changes": [bad], "variables": good_vars}}
}

test_prod_destroy_denied if {
	del := json.patch(good_vm, [{"op": "replace", "path": "/change/actions", "value": ["delete"]}])
	prod_vars := json.patch(good_vars, [{"op": "replace", "path": "/environment/value", "value": "prod"}])
	count(vm_standards.deny) == 1 with input as {"plan": {"resource_changes": [del], "variables": prod_vars}}
}

test_unapproved_datastore_denied if {
	bad_vars := json.patch(good_vars, [{"op": "replace", "path": "/vms/value/dc1lnxapp0101/datastore", "value": "LOCAL-DS"}])
	count(vm_standards.deny) == 1 with input as {"plan": {"resource_changes": [good_vm], "variables": bad_vars}}
}
