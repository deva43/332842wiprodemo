# HCP Terraform OPA policy set definition.
# The authoritative policy set is connected in HCP Terraform (kind = OPA) to the
# tf-policies repository. The same Rego files are vendored here so the pipeline can
# run an early "shift-left" check with conftest on pull requests.

policy "vm_standards" {
  query             = "data.terraform.policies.vm_standards.deny"
  enforcement_level = "mandatory"
}

policy "vm_advisory" {
  query             = "data.terraform.policies.vm_advisory.warn"
  enforcement_level = "advisory"
}
