#!/usr/bin/env bash
# Set the JWT authenticator values after loading github-authn-jwt.yml, then enable the
# authenticator (CONJUR_AUTHENTICATORS or the Conjur UI/API, per your Conjur edition).
set -euo pipefail
svc="conjur/authn-jwt/gh-tf-vmware-vms"
conjur variable set -i "${svc}/issuer"             -v "https://token.actions.githubusercontent.com"
conjur variable set -i "${svc}/jwks-uri"           -v "https://token.actions.githubusercontent.com/.well-known/jwks"
conjur variable set -i "${svc}/token-app-property" -v "environment"
conjur variable set -i "${svc}/identity-path"      -v "github-apps/tf-vmware-vms"
conjur variable set -i "${svc}/enforced-claims"    -v "repository"
conjur variable set -i "${svc}/audience"           -v "https://github.com/bank-org"
