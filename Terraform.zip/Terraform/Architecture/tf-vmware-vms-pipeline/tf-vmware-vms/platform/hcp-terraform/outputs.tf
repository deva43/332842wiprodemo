output "workspace_ids" {
  description = "Workspace IDs by environment."
  value       = { for k, w in tfe_workspace.vms : k => w.id }
}

output "plan_team_ids" {
  description = "Plan team IDs by environment (create team tokens for these and store them in Conjur)."
  value       = { for k, t in tfe_team.plan : k => t.id }
}

output "apply_team_ids" {
  description = "Apply team IDs by environment (create team tokens for these and store them in Conjur)."
  value       = { for k, t in tfe_team.apply : k => t.id }
}
