# Platform-as-code for the HCP Terraform objects this pipeline uses. Apply from the
# platform-admin workspace (owned by the platform team), not from this pipeline.

locals {
  environments = toset(["dev", "test", "prod"])
}

resource "tfe_project" "vmware" {
  organization = var.organization
  name         = "infra-vmware"
}

# API-driven workspaces: no vcs_repo block, so GitHub Actions uploads configuration.
resource "tfe_workspace" "vms" {
  for_each = local.environments

  name                = "vmware-vms-${each.key}-dc1"
  organization        = var.organization
  project_id          = tfe_project.vmware.id
  description         = "VMware VMs (${each.key}, DC1). Managed by GitHub Actions in tf-vmware-vms."
  terraform_version   = var.terraform_version
  working_directory   = "environments/${each.key}"
  auto_apply          = false
  assessments_enabled = true
  tag_names           = ["env:${each.key}", "location:dc1", "service:vmware-vms"]
}

resource "tfe_workspace_settings" "vms" {
  for_each = local.environments

  workspace_id   = tfe_workspace.vms[each.key].id
  execution_mode = "agent"
  agent_pool_id  = var.agent_pool_id
}

# One team per environment for planning and one for applying. Their team tokens are
# created by a platform admin and stored only in CyberArk Conjur.
resource "tfe_team" "plan" {
  for_each     = local.environments
  name         = "gha-vmware-${each.key}-plan"
  organization = var.organization
  visibility   = "secret"
}

resource "tfe_team" "apply" {
  for_each     = local.environments
  name         = "gha-vmware-${each.key}-apply"
  organization = var.organization
  visibility   = "secret"
}

resource "tfe_team_access" "plan" {
  for_each     = local.environments
  team_id      = tfe_team.plan[each.key].id
  workspace_id = tfe_workspace.vms[each.key].id

  permissions {
    runs              = "plan"
    variables         = "read"
    state_versions    = "read-outputs"
    sentinel_mocks    = "none"
    workspace_locking = false
    run_tasks         = false
  }
}

resource "tfe_team_access" "apply" {
  for_each     = local.environments
  team_id      = tfe_team.apply[each.key].id
  workspace_id = tfe_workspace.vms[each.key].id

  permissions {
    runs              = "apply"
    variables         = "read"
    state_versions    = "read-outputs"
    sentinel_mocks    = "none"
    workspace_locking = false
    run_tasks         = false
  }
}

# OPA policy set sourced from the tf-policies repository, applied to the project.
resource "tfe_policy_set" "vmware_opa" {
  name          = "ps-vmware-opa"
  description   = "Mandatory VMware VM standards (OPA)."
  organization  = var.organization
  kind          = "opa"
  overridable   = false
  policies_path = "/"
  project_ids   = [tfe_project.vmware.id]

  vcs_repo {
    identifier                 = var.policy_repo_identifier
    branch                     = "main"
    github_app_installation_id = var.github_app_installation_id
  }
}
