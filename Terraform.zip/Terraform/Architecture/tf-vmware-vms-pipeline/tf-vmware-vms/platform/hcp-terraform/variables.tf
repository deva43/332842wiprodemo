variable "organization" {
  description = "HCP Terraform organisation."
  type        = string
  default     = "bank-org"
}

variable "terraform_version" {
  description = "Approved Terraform version for the workspaces."
  type        = string
}

variable "agent_pool_id" {
  description = "ID of the on-premises agent pool for DC1."
  type        = string
}

variable "policy_repo_identifier" {
  description = "GitHub repository holding the OPA policy set, e.g. bank-org/tf-policies."
  type        = string
}

variable "github_app_installation_id" {
  description = "HCP Terraform GitHub App installation ID (for the policy set VCS link)."
  type        = string
}
