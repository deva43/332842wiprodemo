## Change summary

<!-- What is changing and why -->

## Change record

- ITSM change reference: CHG
- Environments affected: [ ] dev  [ ] test  [ ] prod

## Checklist

- [ ] `change_ref` updated in `terraform.auto.tfvars` for new or changed VMs
- [ ] IP addresses reserved in IPAM
- [ ] Speculative plans reviewed for every affected environment
- [ ] No destroy/replace of production VMs (or exception approved)
- [ ] Ansible baseline templates exist for the OS types being deployed
