terraform {
  required_version = ">= 1.9.0"

  # API-driven workspace in HCP Terraform. The GitHub Actions pipeline uploads this
  # repository as a configuration version; the workspace working directory is set to
  # environments/<env>. Runs execute on the on-premises agent pool.
  cloud {
    organization = "bank-org"

    workspaces {
      name = "vmware-vms-test-dc1"
    }
  }

  required_providers {
    vsphere = {
      source  = "vmware/vsphere"
      version = "~> 2.10"
    }
    conjur = {
      source  = "cyberark/conjur"
      version = "~> 0.6"
    }
  }
}
