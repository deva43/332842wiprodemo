environment         = "test"
vsphere_server      = "vcenter-np.bank.example"
vsphere_user        = "svc_tf_vsphere_test@bank.example"
vsphere_user_object = "svc_tf_vsphere_test"
conjur_base_path    = "terraform/vmware/test"

datacenter = "DC1"
cluster    = "DC1-NP-CL01"
folder     = "Terraform/test"

domain      = "bank.example"
dns_servers = ["10.10.0.10", "10.10.0.11"]

windows_domain_join_user = "svc_domainjoin_np@bank.example"
windows_ou               = "OU=Test,OU=Servers,DC=bank,DC=example"

templates = {
  linux   = "tpl-rhel9-cis-2026-10"
  windows = "tpl-win2022-cis-2026-10"
}

custom_attribute_ids = {
  owner               = "601"
  cost_centre         = "602"
  environment         = "603"
  application         = "604"
  data_classification = "605"
  change_ref          = "606"
}

vms = {
  "dc1lnxapp0201" = {
    os_type             = "linux"
    num_cpus            = 2
    memory_mb           = 4096
    disk_size_gb        = 60
    datastore           = "DC1-NP-DS01"
    network             = "PG-TST-APP-120"
    ipv4_address        = "10.20.120.21"
    ipv4_netmask        = 24
    ipv4_gateway        = "10.20.120.1"
    owner               = "payments-platform"
    cost_centre         = "CC1234"
    application         = "app01"
    data_classification = "internal"
    change_ref          = "CHG0012345"
  }
  "dc1winapp0201" = {
    os_type             = "windows"
    num_cpus            = 4
    memory_mb           = 8192
    disk_size_gb        = 100
    datastore           = "DC1-NP-DS01"
    network             = "PG-TST-APP-120"
    ipv4_address        = "10.20.120.22"
    ipv4_netmask        = 24
    ipv4_gateway        = "10.20.120.1"
    owner               = "payments-platform"
    cost_centre         = "CC1234"
    application         = "app01"
    data_classification = "internal"
    change_ref          = "CHG0012345"
  }
}
