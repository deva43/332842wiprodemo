environment         = "prod"
vsphere_server      = "vcenter-p.bank.example"
vsphere_user        = "svc_tf_vsphere_prod@bank.example"
vsphere_user_object = "svc_tf_vsphere_prod"
conjur_base_path    = "terraform/vmware/prod"

datacenter = "DC1"
cluster    = "DC1-P-CL01"
folder     = "Terraform/prod"

domain      = "bank.example"
dns_servers = ["10.10.0.10", "10.10.0.11"]

windows_domain_join_user = "svc_domainjoin_p@bank.example"
windows_ou               = "OU=Prod,OU=Servers,DC=bank,DC=example"

templates = {
  linux   = "tpl-rhel9-cis-2026-10"
  windows = "tpl-win2022-cis-2026-10"
}

custom_attribute_ids = {
  owner               = "601"
  cost_centre         = "602"
  environment         = "603"
  application         = "604"
  data_classification = "605"
  change_ref          = "606"
}

vms = {
  "dc1lnxapp0901" = {
    os_type             = "linux"
    num_cpus            = 2
    memory_mb           = 4096
    disk_size_gb        = 60
    datastore           = "DC1-P-DS01"
    network             = "PG-PRD-APP-210"
    ipv4_address        = "10.30.210.21"
    ipv4_netmask        = 24
    ipv4_gateway        = "10.30.210.1"
    owner               = "payments-platform"
    cost_centre         = "CC1234"
    application         = "app01"
    data_classification = "confidential"
    change_ref          = "CHG0012345"
  }
  "dc1winapp0901" = {
    os_type             = "windows"
    num_cpus            = 4
    memory_mb           = 8192
    disk_size_gb        = 100
    datastore           = "DC1-P-DS01"
    network             = "PG-PRD-APP-210"
    ipv4_address        = "10.30.210.22"
    ipv4_netmask        = 24
    ipv4_gateway        = "10.30.210.1"
    owner               = "payments-platform"
    cost_centre         = "CC1234"
    application         = "app01"
    data_classification = "confidential"
    change_ref          = "CHG0012345"
  }
}
