# Consumed by the pipeline to drive Ansible (AAP) configuration. Contains no secrets.
output "vm_inventory" {
  description = "Deployed VMs: name => fqdn, ip and os_type."
  value = {
    for name, m in module.vm : name => {
      fqdn         = m.fqdn
      ipv4_address = m.ipv4_address
      os_type      = m.os_type
    }
  }
}

output "linux_hosts" {
  description = "Comma-separated Linux FQDNs (AAP limit)."
  value       = join(",", [for m in module.vm : m.fqdn if m.os_type == "linux"])
}

output "windows_hosts" {
  description = "Comma-separated Windows FQDNs (AAP limit)."
  value       = join(",", [for m in module.vm : m.fqdn if m.os_type == "windows"])
}
