module "vm" {
  source   = "../../modules/vsphere-vm"
  for_each = var.vms

  name          = each.key
  os_type       = each.value.os_type
  template_name = each.value.os_type == "windows" ? var.templates.windows : var.templates.linux

  datacenter = var.datacenter
  cluster    = var.cluster
  datastore  = each.value.datastore
  network    = each.value.network
  folder     = var.folder

  num_cpus     = each.value.num_cpus
  memory_mb    = each.value.memory_mb
  disk_size_gb = each.value.disk_size_gb

  ipv4_address = each.value.ipv4_address
  ipv4_netmask = each.value.ipv4_netmask
  ipv4_gateway = each.value.ipv4_gateway
  dns_servers  = var.dns_servers
  domain       = var.domain

  windows_admin_password       = each.value.os_type == "windows" ? data.conjur_secret.windows_local_admin.value : null
  windows_domain_join_user     = each.value.os_type == "windows" ? var.windows_domain_join_user : null
  windows_domain_join_password = each.value.os_type == "windows" ? data.conjur_secret.windows_domain_join.value : null
  windows_ou                   = each.value.os_type == "windows" ? var.windows_ou : null

  custom_attribute_ids = var.custom_attribute_ids

  tags = {
    owner               = each.value.owner
    cost_centre         = each.value.cost_centre
    environment         = var.environment
    application         = each.value.application
    data_classification = each.value.data_classification
    change_ref          = each.value.change_ref
  }
}
