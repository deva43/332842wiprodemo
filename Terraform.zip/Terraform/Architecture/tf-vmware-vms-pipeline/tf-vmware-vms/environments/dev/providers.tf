# CyberArk Conjur (Secrets Manager). Connection and authentication are supplied by
# environment variables on the HCP Terraform run (set at project level by the platform
# team), for example CONJUR_APPLIANCE_URL, CONJUR_ACCOUNT, CONJUR_AUTHN_LOGIN and the
# approved authentication method. No Conjur credential is stored in this repository.
provider "conjur" {}

data "conjur_secret" "vsphere_password" {
  name = "${var.conjur_base_path}/vsphere/${var.vsphere_user_object}/password"
}

data "conjur_secret" "windows_local_admin" {
  name = "${var.conjur_base_path}/windows/local-admin/password"
}

data "conjur_secret" "windows_domain_join" {
  name = "${var.conjur_base_path}/windows/domain-join/password"
}

provider "vsphere" {
  user                 = var.vsphere_user
  password             = data.conjur_secret.vsphere_password.value
  vsphere_server       = var.vsphere_server
  allow_unverified_ssl = false
  api_timeout          = 10
}
