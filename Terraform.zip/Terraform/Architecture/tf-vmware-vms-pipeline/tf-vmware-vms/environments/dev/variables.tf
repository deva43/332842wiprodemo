variable "environment" {
  description = "Environment name (dev, test, prod)."
  type        = string

  validation {
    condition     = contains(["dev", "test", "prod"], var.environment)
    error_message = "environment must be dev, test or prod."
  }
}

variable "vsphere_server" {
  description = "vCenter FQDN."
  type        = string
}

variable "vsphere_user" {
  description = "vCenter service account UPN used by Terraform."
  type        = string
}

variable "vsphere_user_object" {
  description = "Conjur object name of the vCenter service account."
  type        = string
}

variable "conjur_base_path" {
  description = "Conjur policy branch holding secrets for this environment."
  type        = string
}

variable "datacenter" {
  description = "vSphere datacenter."
  type        = string
}

variable "cluster" {
  description = "vSphere cluster."
  type        = string
}

variable "folder" {
  description = "VM folder for this environment."
  type        = string
}

variable "domain" {
  description = "DNS / AD domain."
  type        = string
}

variable "dns_servers" {
  description = "DNS servers."
  type        = list(string)
}

variable "windows_domain_join_user" {
  description = "Domain join service account (UPN). Password comes from CyberArk."
  type        = string
}

variable "windows_ou" {
  description = "AD OU for Windows servers in this environment."
  type        = string
}

variable "templates" {
  description = "Approved template per OS family."
  type = object({
    linux   = string
    windows = string
  })
}

variable "custom_attribute_ids" {
  description = "Map of tag key => vSphere custom attribute ID."
  type        = map(string)
}

variable "vms" {
  description = "VMs to deploy, keyed by VM name."
  type = map(object({
    os_type             = string
    num_cpus            = number
    memory_mb           = number
    disk_size_gb        = number
    datastore           = string
    network             = string
    ipv4_address        = string
    ipv4_netmask        = number
    ipv4_gateway        = string
    owner               = string
    cost_centre         = string
    application         = string
    data_classification = string
    change_ref          = string
  }))
}
