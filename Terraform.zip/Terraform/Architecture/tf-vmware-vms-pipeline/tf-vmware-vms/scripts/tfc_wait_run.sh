#!/usr/bin/env bash
# Wait for an HCP Terraform run to reach a final state and fail if it did not apply.
# Usage: tfc_wait_run.sh <run-id> [timeout-seconds]
set -euo pipefail
# shellcheck source=scripts/lib.sh
source "$(dirname "$0")/lib.sh"

run_id="${1:?run id required}"
timeout="${2:-5400}"
waited=0

while :; do
  status=$(tfc_api GET "/runs/${run_id}" | jq -r '.data.attributes.status')
  case "${status}" in
    applied|planned_and_finished)
      log "Run ${run_id} finished with status ${status}"
      exit 0 ;;
    errored|canceled|force_canceled|discarded|policy_soft_failed)
      die "Run ${run_id} ended with status ${status}" ;;
    *)
      log "Run ${run_id} status: ${status}" ;;
  esac
  [ "${waited}" -ge "${timeout}" ] && die "Timed out after ${timeout}s waiting for run ${run_id}"
  sleep 15
  waited=$((waited + 15))
done
