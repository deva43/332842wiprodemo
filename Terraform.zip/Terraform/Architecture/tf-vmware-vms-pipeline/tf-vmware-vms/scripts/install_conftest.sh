#!/usr/bin/env bash
# Install a pinned conftest version with checksum verification (skips if present).
# Usage: install_conftest.sh <version e.g. 0.56.0>
set -euo pipefail

version="${1:?conftest version required}"
bin_dir="${HOME}/.local/bin"
mkdir -p "${bin_dir}"

if command -v conftest > /dev/null && conftest --version | grep -q "${version}"; then
  echo "conftest ${version} already installed"
  exit 0
fi

tmp=$(mktemp -d)
trap 'rm -rf "${tmp}"' EXIT
base="https://github.com/open-policy-agent/conftest/releases/download/v${version}"
file="conftest_${version}_Linux_x86_64.tar.gz"

curl -sSfL -o "${tmp}/${file}" "${base}/${file}"
curl -sSfL -o "${tmp}/checksums.txt" "${base}/checksums.txt"
(cd "${tmp}" && grep " ${file}\$" checksums.txt | sha256sum --check --strict)
tar -xzf "${tmp}/${file}" -C "${tmp}" conftest
install -m 0755 "${tmp}/conftest" "${bin_dir}/conftest"
[ -n "${GITHUB_PATH:-}" ] && echo "${bin_dir}" >> "${GITHUB_PATH}"
"${bin_dir}/conftest" --version
