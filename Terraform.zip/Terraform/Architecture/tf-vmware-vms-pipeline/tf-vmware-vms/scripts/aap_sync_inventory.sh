#!/usr/bin/env bash
# Trigger an AAP inventory source update (for example the VMware vCenter source) and
# wait for it to finish, so newly built VMs are present before configuration.
# Usage: aap_sync_inventory.sh <inventory-source-id> [timeout-seconds]
set -euo pipefail
# shellcheck source=scripts/lib.sh
source "$(dirname "$0")/lib.sh"

src_id="${1:?inventory source id required}"
timeout="${2:-900}"
waited=0

update_id=$(aap_api POST "/inventory_sources/${src_id}/update/" '{}' | jq -r '.inventory_update // .id')
[ -n "${update_id}" ] && [ "${update_id}" != "null" ] || die "Could not start inventory update"
log "Inventory update ${update_id} started"

while :; do
  status=$(aap_api GET "/inventory_updates/${update_id}/" | jq -r '.status')
  case "${status}" in
    successful) log "Inventory update ${update_id} successful"; exit 0 ;;
    failed|error|canceled) die "Inventory update ${update_id} ended with status ${status}" ;;
    *) log "Inventory update ${update_id}: ${status}" ;;
  esac
  [ "${waited}" -ge "${timeout}" ] && die "Timed out waiting for inventory update ${update_id}"
  sleep 10
  waited=$((waited + 10))
done
