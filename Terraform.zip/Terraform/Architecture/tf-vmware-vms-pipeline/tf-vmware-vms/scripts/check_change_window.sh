#!/usr/bin/env bash
# Block production applies outside the approved change window or during a freeze.
# Configuration (GitHub environment variables on "prod"):
#   CHANGE_FREEZE=true|false
#   CHANGE_WINDOW_DAYS="Tue,Wed,Thu"      (UTC day names)
#   CHANGE_WINDOW_START_UTC=18            (hour, inclusive)
#   CHANGE_WINDOW_END_UTC=23              (hour, exclusive)
# Extend this script to query the ITSM change record if required.
set -euo pipefail

freeze="${CHANGE_FREEZE:-false}"
days="${CHANGE_WINDOW_DAYS:-Mon,Tue,Wed,Thu,Fri}"
start="${CHANGE_WINDOW_START_UTC:-0}"
end="${CHANGE_WINDOW_END_UTC:-24}"

if [ "${freeze}" = "true" ]; then
  echo "::error::Change freeze is active; production apply blocked"
  exit 1
fi

today=$(date -u +%a)
hour=$((10#$(date -u +%H)))

if [[ ",${days}," != *",${today},"* ]]; then
  echo "::error::${today} is outside the approved change days (${days})"
  exit 1
fi

if [ "${hour}" -lt "${start}" ] || [ "${hour}" -ge "${end}" ]; then
  echo "::error::${hour}:00 UTC is outside the change window ${start}:00-${end}:00 UTC"
  exit 1
fi

echo "Within change window (${today} ${hour}:00 UTC)"
