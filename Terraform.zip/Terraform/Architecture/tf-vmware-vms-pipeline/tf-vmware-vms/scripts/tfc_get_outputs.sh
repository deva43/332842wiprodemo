#!/usr/bin/env bash
# Read non-sensitive outputs of the current state version and expose them as GitHub
# step outputs: linux_hosts, windows_hosts.
# Usage: tfc_get_outputs.sh <workspace-name>
set -euo pipefail
# shellcheck source=scripts/lib.sh
source "$(dirname "$0")/lib.sh"
require_env TF_CLOUD_ORGANIZATION GITHUB_OUTPUT

ws_name="${1:?workspace name required}"

ws_id=$(tfc_api GET "/organizations/${TF_CLOUD_ORGANIZATION}/workspaces/${ws_name}" | jq -r '.data.id')
[ -n "${ws_id}" ] && [ "${ws_id}" != "null" ] || die "Workspace ${ws_name} not found"

outputs=$(tfc_api GET "/workspaces/${ws_id}/current-state-version-outputs")

get_output() {
  echo "${outputs}" | jq -r --arg n "$1" \
    '.data[] | select(.attributes.name == $n and .attributes.sensitive == false) | .attributes.value // ""'
}

linux_hosts=$(get_output linux_hosts)
windows_hosts=$(get_output windows_hosts)

{
  echo "linux_hosts=${linux_hosts}"
  echo "windows_hosts=${windows_hosts}"
} >> "${GITHUB_OUTPUT}"

log "Linux hosts: ${linux_hosts:-<none>}"
log "Windows hosts: ${windows_hosts:-<none>}"
