#!/usr/bin/env bash
# Shared helpers for pipeline scripts. Sourced, not executed.
# Requires: curl, jq. Never prints tokens.

set -euo pipefail

: "${TF_CLOUD_HOSTNAME:=app.terraform.io}"

log() { printf '[%s] %s\n' "$(date -u +%H:%M:%SZ)" "$*" >&2; }
die() { printf '::error::%s\n' "$*" >&2; exit 1; }

require_env() {
  local v
  for v in "$@"; do
    [ -n "${!v:-}" ] || die "Required environment variable ${v} is not set"
  done
}

# tfc_api METHOD PATH [JSON_BODY]
tfc_api() {
  require_env TF_API_TOKEN
  local method="$1" path="$2" body="${3:-}"
  local args=(--silent --show-error --fail-with-body --location --retry 3 --retry-delay 5
    --header "Authorization: Bearer ${TF_API_TOKEN}"
    --header "Content-Type: application/vnd.api+json"
    --request "${method}")
  [ -n "${body}" ] && args+=(--data "${body}")
  curl "${args[@]}" "https://${TF_CLOUD_HOSTNAME}/api/v2${path}"
}

# aap_api METHOD PATH [JSON_BODY]   (AAP 2.5+ platform gateway; controller API under /api/controller/v2)
aap_api() {
  require_env AAP_TOKEN AAP_HOST
  local method="$1" path="$2" body="${3:-}"
  local args=(--silent --show-error --fail-with-body --retry 3 --retry-delay 5
    --header "Authorization: Bearer ${AAP_TOKEN}"
    --header "Content-Type: application/json"
    --request "${method}")
  [ -n "${AAP_CA_BUNDLE:-}" ] && args+=(--cacert "${AAP_CA_BUNDLE}")
  [ -n "${body}" ] && args+=(--data "${body}")
  curl "${args[@]}" "https://${AAP_HOST}/api/controller/v2${path}"
}
