#!/usr/bin/env bash
# Download the redacted JSON execution plan of an HCP Terraform plan.
# Usage: tfc_get_json_plan.sh <plan-id> <output-file>
# Redacted output removes sensitive values; the file is still deleted after use.
set -euo pipefail
# shellcheck source=scripts/lib.sh
source "$(dirname "$0")/lib.sh"

plan_id="${1:?plan id required}"
out="${2:?output file required}"

log "Downloading redacted JSON plan for ${plan_id}"
tfc_api GET "/plans/${plan_id}/json-output-redacted" > "${out}"
jq -e '.resource_changes != null or .planned_values != null' "${out}" > /dev/null \
  || die "Downloaded plan JSON is not valid"
log "Saved $(jq '.resource_changes | length' "${out}") resource changes to ${out}"
