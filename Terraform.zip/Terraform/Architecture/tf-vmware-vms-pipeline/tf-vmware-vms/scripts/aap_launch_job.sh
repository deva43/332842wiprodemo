#!/usr/bin/env bash
# Launch an AAP job template limited to the given hosts and wait for the result.
# The job template must have "Prompt on launch" enabled for Limit and Variables.
# Usage: aap_launch_job.sh <job-template-id> <comma-separated-hosts> [extra-vars-json] [timeout-seconds]
set -euo pipefail
# shellcheck source=scripts/lib.sh
source "$(dirname "$0")/lib.sh"

template_id="${1:?job template id required}"
hosts="${2:?host list required}"
extra_vars="${3:-{\}}"
timeout="${4:-5400}"
waited=0

echo "${extra_vars}" | jq -e . > /dev/null || die "extra_vars is not valid JSON"

body=$(jq -n --arg limit "${hosts}" --argjson ev "${extra_vars}" '{limit: $limit, extra_vars: $ev}')
job_id=$(aap_api POST "/job_templates/${template_id}/launch/" "${body}" | jq -r '.job // .id')
[ -n "${job_id}" ] && [ "${job_id}" != "null" ] || die "Could not launch job template ${template_id}"
log "AAP job ${job_id} launched for: ${hosts}"
echo "AAP job: https://${AAP_HOST}/execution/jobs/playbook/${job_id}/output" >> "${GITHUB_STEP_SUMMARY:-/dev/null}"

while :; do
  status=$(aap_api GET "/jobs/${job_id}/" | jq -r '.status')
  case "${status}" in
    successful)
      log "AAP job ${job_id} successful"
      exit 0 ;;
    failed|error|canceled)
      log "Last lines of job output:"
      aap_api GET "/jobs/${job_id}/stdout/?format=txt" | tail -n 40 || true
      die "AAP job ${job_id} ended with status ${status}" ;;
    *)
      log "AAP job ${job_id}: ${status}" ;;
  esac
  [ "${waited}" -ge "${timeout}" ] && die "Timed out waiting for AAP job ${job_id}"
  sleep 15
  waited=$((waited + 15))
done
