# tf-vmware-vms

Deploys Linux and Windows virtual machines to VMware vSphere through HCP Terraform
(SaaS) with on-premises agents, then configures them with Red Hat Ansible Automation
Platform. Secrets come from CyberArk Conjur; policies are enforced with OPA.

## Layout

| Path | Purpose |
|------|---------|
| `environments/<env>/` | Root module per environment (HCP Terraform working directory) |
| `modules/vsphere-vm/` | VM module (publish to the private registry in production) |
| `policies/` | OPA policies (also connected to HCP Terraform as a policy set) |
| `scripts/` | Pipeline helper scripts |
| `platform/` | HCP Terraform and Conjur configuration used by this pipeline |
| `.github/workflows/` | GitHub Actions pipelines |

## How to deploy a VM

1. Reserve the IP in IPAM and raise the change record.
2. Add the VM to `vms` in `environments/<env>/terraform.auto.tfvars`.
3. Open a pull request; review the speculative plans and policy results.
4. Merge; approve the `test` and `prod` deployments in GitHub when prompted.
